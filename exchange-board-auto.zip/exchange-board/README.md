# لوحة أسعار العملات — الشركة العالمية إكسبرس

نشر تلقائي كامل على Cloudflare (الموقع + المزامنة + رفع الصور) برابط واحد.

## الإعداد (مرة واحدة)
1. فعّل R2 في حساب Cloudflare (مجاني): Dashboard ← R2 ← Get started.
2. أنشئ API Token: My Profile ← API Tokens ← قالب "Edit Cloudflare Workers" وأضف صلاحية R2 (Edit).
3. في GitHub: Settings ← Secrets and variables ← Actions ← أضف:
   - CLOUDFLARE_API_TOKEN
   - CLOUDFLARE_ACCOUNT_ID
   - ADMIN_KEY  (كلمة مرور لوحة التحكم)
4. ارفع المشروع إلى GitHub (فرع main). كل push بعدها ينشر تلقائياً.

## بدون GitHub
    npm install
    npx wrangler login
    npx wrangler secret put ADMIN_KEY
    npx wrangler deploy

اللوحة: الرابط الرئيسي — لوحة التحكم: الرابط + #admin
