# مرجع مختصر — worker.js

## ثوابت على مستوى الملف
- DEFAULT_KEY (const string)
  - القيمة: 'exchange-board-state-v6'
  - الوصف: مفتاح افتراضي لاستخدامه عند تخزين/استرجاع حالة اللوحة في KV إذا لم يُقدّم مفتاح.

## دوال مساعدة (Top-level)
- corsHeaders()
  - توقيع: () -> Object
  - يُرجع كائن رؤوس CORS:
    - Access-Control-Allow-Origin: '*'
    - Access-Control-Allow-Methods: 'GET, POST, DELETE, OPTIONS'
    - Access-Control-Allow-Headers: 'Content-Type, X-Admin-Key'

- json(data, status = 200, extraHeaders = {})
  - توقيع: (any, number?, Object?) -> Response
  - يُحوّل البيانات إلى JSON ويُعيد Response مع دمج رؤوس CORS، 'Content-Type: application/json'، وأي رؤوس إضافية (مثال: Cache-Control).
  - يُستخدم للردود الناجحة والخاطئة في معظم المسارات.

- extFromContentType(ct)
  - توقيع: (string|undefined) -> string
  - يُعيد امتداد ملف بناءً على محتوى النوع (png, jpg, webp, gif, svg) أو 'bin' كافتراضي.
  - يُستخدم عند توليد اسم ملف للصورة في R2.

- base64ToBytes(base64)
  - توقيع: (string) -> Uint8Array
  - يفك ترميز سلسلة base64 إلى مصفوفة بايتات (Uint8Array) باستخدام atob.
  - يُستخدم قبل رفع البيانات إلى R2.

## نقطة الدخول (Cloudflare Worker)
- export default { async fetch(request, env) { ... } }
  - توقيع: async fetch(Request, env) -> Response
  - الوصف: معالج الطلبات الرئيسي. يدير المسارات التالية:
    - OPTIONS * : استجابة CORS preflight.
    - GET /api/verify : يتحقق من ترويسة X-Admin-Key مقابل env.ADMIN_KEY، يعيد { valid: true/false }.
    - GET /api/state : يقرأ قيمة من KV (env.BOARD_KV.get) بناءً على query param `key` أو DEFAULT_KEY، يعيد { key, value } أو 404 إذا لم توجد.
    - POST /api/state : محمي بواسطة X-Admin-Key؛ يتوقع JSON { key?, value } حيث يجب أن تكون value سلسلة، ثم يحفظها في KV.
    - POST /api/upload : محمي بواسطة X-Admin-Key؛ يتوقع JSON { contentType, dataBase64 }، يفك ترميز الصورة، ينشئ مفتاحاً (img-<timestamp>-<rand>.<ext>) ويرفع bytes إلى env.BOARD_R2.put مع httpMetadata.contentType، ثم يعيد { key, url }.
    - GET /api/image/:key : يقرأ الكائن من env.BOARD_R2.get(key) ويعيد الجسم مع Content-Type مناسب و Cache-Control طويل.
    - DELETE /api/image/:key : محمي بواسطة X-Admin-Key؛ يحذف الكائن من R2 ويعيد { key, deleted: true }.
    - غير ذلك: يعيد أخطاء مناسبة (405 للطرق غير المسموح بها، 401 لغير المصرح، 404 للمسارات غير المعروفة).

## متغيرات محلية مستخدمة داخل fetch (per-request)
- url — new URL(request.url) — لتحليل المسار والاستعلام.
- adminKey — request.headers.get('X-Admin-Key') || '' — قيمة رأس الإدارة للتحقق.
- body — نتيجة await request.json() عند الحاجة.
- key — مفتاح KV أو اسم ملف R2 (من query، body، أو مُولّد).
- value — نص الحالة عند POST /api/state.
- contentType — نوع المحتوى المرسل لرفع الصورة (افتراضي 'application/octet-stream').
- dataBase64 — سلسلة base64 للصورة من جسم الطلب.
- bytes — Uint8Array بعد فك ترميز base64.
- imageUrl — عنوان عام منشأ للصورة المرفوعة: `${url.origin}/api/image/${key}`.
- obj — نتيجة env.BOARD_R2.get(key) عند تقديم صورة.

## متوقع من البيئة (env bindings)
- env.ADMIN_KEY (secret) — سلسلة سرية لمصادقة طلبات الإدارة.
- env.BOARD_KV (KV namespace) — تخزين/استرجاع حالة التطبيق.
- env.BOARD_R2 (R2 bucket) — اختياري؛ لتخزين/استرجاع/حذف الصور.

## ملاحظات قصيرة
- جميع الردود تتضمن رؤوس CORS عبر corsHeaders().
- دوال المساعدة صغيرة ومركزة: json() لتوحيد الردود، extFromContentType() لتعيين امتدادات، base64ToBytes() لفك ترميز البيانات.
