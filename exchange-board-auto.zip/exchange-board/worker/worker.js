/**
 * Cloudflare Worker — backend API for the currency exchange board.
 * Stores the board's full state (currencies, branches, slides, company info)
 * in a KV namespace so the control panel and the display board can sync
 * across different devices in real time.
 *
 * Routes:
 *   GET  /api/state            -> public read, returns the saved state
 *   POST /api/state            -> protected write, requires header X-Admin-Key
 *   OPTIONS /api/state         -> CORS preflight
 *   POST /api/upload           -> protected image upload to R2 (body: { dataBase64, contentType, key? })
 *   GET  /api/image/:key       -> serve image from R2
 *   DELETE /api/image/:key     -> delete image from R2 (requires X-Admin-Key)
 *   GET  /api/verify           -> check X-Admin-Key validity
 *
 * Required bindings (set in the Worker's Settings -> Variables):
 *   - KV Namespace binding named "BOARD_KV"
 *   - (optional) R2 bucket binding named "BOARD_R2"
 *   - Secret environment variable named "ADMIN_KEY"
 */

const DEFAULT_KEY = "exchange-board-state-v6";
const KEY_PREFIX = "exchange-board-state-";

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, X-Admin-Key",
  };
}

function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders(), "Content-Type": "application/json", ...extraHeaders },
  });
}

function extFromContentType(ct) {
  if (!ct) return "bin";
  if (ct.includes("png")) return "png";
  if (ct.includes("jpeg") || ct.includes("jpg")) return "jpg";
  if (ct.includes("webp")) return "webp";
  if (ct.includes("gif")) return "gif";
  if (ct.includes("svg")) return "svg";
  return "bin";
}

function base64ToBytes(base64) {
  // Support data URL prefix as well as plain base64
  const cleaned = base64.replace(/^data:.*;base64,/, "");
  // atob is available in the Cloudflare Workers runtime
  const binary = atob(cleaned);
  const len = binary.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // CORS preflight for everything
    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders() });
    }

    /* ---------------- ADMIN KEY VERIFICATION ---------------- */
    if (url.pathname === "/api/verify") {
      if (request.method !== "GET") {
        return json({ error: "method not allowed" }, 405);
      }
      const adminKey = request.headers.get("X-Admin-Key") || "";
      if (!env.ADMIN_KEY || adminKey !== env.ADMIN_KEY) {
        return json({ valid: false }, 401);
      }
      return json({ valid: true });
    }

    /* ---------------- STATE (KV) ---------------- */
    if (url.pathname === "/api/state") {
      if (request.method === "GET") {
        const key = url.searchParams.get("key") || DEFAULT_KEY;
        if (!key.startsWith(KEY_PREFIX)) {
          return json({ error: "invalid key" }, 400);
        }
        const value = await env.BOARD_KV.get(key);
        if (value === null) {
          return json({ error: "not found" }, 404, { "Cache-Control": "no-store" });
        }
        return json({ key, value }, 200, { "Cache-Control": "no-store" });
      }

      if (request.method === "POST") {
        const adminKey = request.headers.get("X-Admin-Key") || "";
        if (!env.ADMIN_KEY || adminKey !== env.ADMIN_KEY) {
          return json({ error: "unauthorized" }, 401);
        }
        let body;
        try {
          body = await request.json();
        } catch (e) {
          return json({ error: "invalid json" }, 400);
        }
        const key = body.key || DEFAULT_KEY;
        if (typeof key !== "string" || !key.startsWith(KEY_PREFIX)) {
          return json({ error: "invalid key" }, 400);
        }
        const value = body.value;
        if (typeof value !== "string") {
          return json({ error: "value must be a string" }, 400);
        }
        await env.BOARD_KV.put(key, value);
        return json({ key, saved: true });
      }

      return json({ error: "method not allowed" }, 405);
    }

    /* ---------------- IMAGE UPLOAD (R2) ---------------- */
    if (url.pathname === "/api/upload") {
      if (request.method !== "POST") {
        return json({ error: "method not allowed" }, 405);
      }
      const adminKey = request.headers.get("X-Admin-Key") || "";
      if (!env.ADMIN_KEY || adminKey !== env.ADMIN_KEY) {
        return json({ error: "unauthorized" }, 401);
      }
      if (!env.BOARD_R2) {
        return json({ error: "R2 bucket not configured on this Worker" }, 500);
      }
      let body;
      try {
        body = await request.json();
      } catch (e) {
        return json({ error: "invalid json" }, 400);
      }
      const contentType = body.contentType || "application/octet-stream";
      const dataBase64 = body.dataBase64;
      if (typeof dataBase64 !== "string" || !dataBase64) {
        return json({ error: "dataBase64 is required" }, 400);
      }
      if (!/^image\/(png|jpeg|jpg|webp|gif)$/.test(contentType)) {
        return json({ error: "unsupported content type" }, 415);
      }
      let bytes;
      try {
        bytes = base64ToBytes(dataBase64);
      } catch (e) {
        return json({ error: "invalid base64 data" }, 400);
      }
      if (bytes.length > 5 * 1024 * 1024) {
        return json({ error: "image too large (max 5MB)" }, 413);
      }
      const key =
        (body.key && String(body.key).replace(/[\/\\#?]/g, "_")) ||
        `img-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${extFromContentType(contentType)}`;
      await env.BOARD_R2.put(key, bytes, { httpMetadata: { contentType } });
      return json({ key, uploaded: true, url: `${url.origin}/api/image/${encodeURIComponent(key)}` });
    }

    /* ---------------- IMAGE SERVE / DELETE (R2) ---------------- */
    if (url.pathname.startsWith("/api/image/")) {
      if (!env.BOARD_R2) {
        return json({ error: "R2 bucket not configured on this Worker" }, 500);
      }
      const key = decodeURIComponent(url.pathname.replace("/api/image/", ""));

      if (request.method === "GET") {
        const obj = await env.BOARD_R2.get(key);
        if (!obj) {
          return json({ error: "not found" }, 404);
        }
        return new Response(obj.body, {
          headers: {
            ...corsHeaders(),
            "Content-Type": obj.httpMetadata?.contentType || "application/octet-stream",
            "Cache-Control": "public, max-age=31536000, immutable",
          },
        });
      }
      if (request.method === "DELETE") {
        const adminKey = request.headers.get("X-Admin-Key") || "";
        if (!env.ADMIN_KEY || adminKey !== env.ADMIN_KEY) {
          return json({ error: "unauthorized" }, 401);
        }
        await env.BOARD_R2.delete(key);
        return json({ key, deleted: true });
      }

      return json({ error: "method not allowed" }, 405);
    }

    return json({ error: "not found" }, 404);
  },
};
